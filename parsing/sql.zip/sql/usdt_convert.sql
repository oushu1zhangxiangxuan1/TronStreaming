-- 1. 核对数据
SELECT count(1) FROM usdt_trans_ret
WHERE contract_address = 'TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t';

-- 2. 创建表 
-- TODO: 需要把被查的表名改为内部orc表名
CREATE TABLE usdt_trans_ret
WITH (appendonly = true, orientation = orc, compresstype = lz4, dicthreshold = 0.8)
AS 
SELECT * FROM trans_ret
WHERE contract_address = 'TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t'
ORDER BY id;

CREATE TABLE usdt_trans_ret_log
AS
SELECT a.* FROM 
trans_ret_log a
JOIN
usdt_trans_ret b
ON b.id = a.trans_id
ORDER BY a.trans_id;


CREATE TABLE usdt_trans_ret_log_topics
AS
SELECT a.* FROM 
trans_ret_log_topics a
JOIN
usdt_trans_ret b
ON b.id = a.trans_id
ORDER BY a.trans_id;


-- 核对都有调用了哪些函数
-- 核对topic 0 是什么，distinct count
SELECT count(1) 
FROM(
    SELECT topic 
    FROM usdt_trans_ret_log_topics
    WHERE topic_index = 1
    GROUP BY topic
) a;

-- 核对对多有几个tpoic

SELECT max_index
FROM(
    SELECT trans_id, max(topic_index) as max_index
    FROM usdt_trans_ret_log_topics
    GROUP BY trans_id
) a
GROUP BY max_index;

-- TODO: 将这三个表导出为csv

-- 解析完建一个新表导入

-- 新表的from需要通过交易hash连接trans表的from