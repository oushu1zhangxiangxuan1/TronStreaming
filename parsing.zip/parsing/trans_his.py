# Pre work:
# 核实与浏览器数据一致性: 无法与浏览器数据严格对齐
# 评估数据量: 约等同于block数据量
# hex string to bytes: bytes.fromhex


# 设计表结构
# 读配置文件
# 连接数据库
# 开始解析
